from django.apps import AppConfig


class ForsaleConfig(AppConfig):
    name = 'forSale'
