from django.conf.urls import url
from django.urls import path, include
from notice import views

app_name = 'franchise'

urlpatterns = [
    # 공지사항
    path('', views.franchise_list, name='franchise_list'),
    path('<int:pk>/', views.franchise_detail, name='franchise_detail'),
    path('new/', views.franchise_new, name='franchise_new'),  # 등록
    path('remove/<int:pk>/', views.franchise_remove, name='franchise_remove'),  # 삭제
    path('edit/<int:pk>/', views.franchise_edit, name='franchise_edit'),  # 수정
    #
]
