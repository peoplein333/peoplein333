import re

from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, render, redirect

from django.views.generic import CreateView, UpdateView, DeleteView

from franchise.forms import FranchiseForm
from franchise.models import Franchise


from django.shortcuts import render, redirect

from django.views.generic.base import TemplateView

# 공지사항

def franchise_list(request):
    qs = Franchise.objects.filter()
    return render(request, 'franchise/franchise_list.html',
                  {'franchise_list': qs})

def franchise_detail(request, pk):
    franchise = get_object_or_404(Franchise, pk=pk)
    is_liked = False
    # if franchise.likes.filter(id=request.user.id).exists():
    #     is_liked = True
    context = {
        'franchise': franchise,
        # 'is_liked': is_liked,
        # 'total_likes': franchise.total_likes(),
    }
    return render(request, 'franchise/franchise_detail.html',
                  context)

def franchise_new(request):
    if request.method == 'POST':
        form = FranchiseForm(request.POST)
        if form.is_valid():
            franchise = form.save(commit=False)
            franchise.author = request.user
            franchise.save()
            return redirect('franchise:franchise_detail', pk=franchise.pk)
    else:
        form = FranchiseForm()
    return render(request, 'franchise/franchise_form.html', {'form':form})

def franchise_edit(request, pk):
    item = get_object_or_404(Franchise, pk=pk)
    form = FranchiseForm(request.POST or None, instance=item)
    if form.is_valid():
        post = form.save(commit=False)
        post.save()  # 저장하기
        return redirect('/franchise/' + str(item.id))
    return render(request, 'franchise/franchise_form.html', {'form':form})


def franchise_remove(request, pk):
    franchise = get_object_or_404(Franchise, pk=pk)
    franchise.delete()
    return redirect('franchise:franchise_list')
#

# # 여기부터 프랜차이즈
# def franchise_list(request):
#     qs = Franchise.objects.filter()
#     return render(request, 'notice/../franchise/templates/franchise/franchise_list.html',
#                   {'franchise_list': qs})
#
# def franchise_detail(request, pk):
#     notice = get_object_or_404(Notice, pk=pk)
#     return render(request, 'notice/../franchise/templates/franchise/franchise_detail.html',
#                   {'notice': notice})

# 프랜차이즈 게시글 수정 삭제 등록
# def franchise_new(request, franchise=None):
#     error_list = []
#     initial = {}
#
#     if request.method == 'POST':
#         data = request.POST
#         files = request.FILES
#
#         title = data.get('title')
#         content = data.get('content')
#         photo = files.get('photo')
#         # board = data.get('board')
#
#         # 유효성 검사
#         if len(title) == 0:
#             error_list.append('title을 1글자 이상 입력해주세요.')
#
#         if re.match(r'^[\da-zA-Z\s]+$', content):
#             error_list.append('한글을 입력해주세요.')
#
#         if not error_list:
#             # 저장 시도
#             if franchise is None:
#                 franchise = Franchise()
#
#             franchise.title = title
#             franchise.content = content
#             if photo:
#                 franchise.photo.save(photo.name, photo, save=False)
#
#             try:
#                 franchise.save()
#             except Exception as e:
#                 error_list.append(e)
#             else:
#                 # return redirect(item)  # item.get_absolute_url 호출됨
#                 return redirect('franchise:franchise_list')
#
#         initial = {
#             'title': title,
#             'content': content,
#             'photo': photo,
#             # 'board': board,
#         }
#     else:
#         if franchise is not None:
#             initial = {
#                 'title': franchise.title,
#                 'content': franchise.content,
#                 'photo': franchise.photo,
#                 # 'board': notice.board,
#             }
#     return render(request, 'franchise/../franchise/templates/franchise/franchise_form.html', {
#         'error_list': error_list,
#         'initial': initial,
#     })


# 프랜차이즈 수정
def franchise_edit(request, pk):
    franchise = get_object_or_404(Franchise, pk=pk)
    return franchise_new(request, franchise)

# 프랜차이즈 삭제
def franchise_remove(request, pk):
    franchise = get_object_or_404(Franchise, pk=pk)
    franchise.delete()
    return redirect('franchise:franchise_list')
#

# def like_notice(request):
#     notice = get_object_or_404(Notice, id=request.POST.get('notice_id'))
#     is_liked = False
#     if notice.likes.filter(id=request.user.id).exists():
#         notice.likes.remove(request.user)
#         is_liked = False
#     else:
#         notice.likes.add(request.user)
#         is_liked = True
#     return HttpResponseRedirect(notice.get_absolute_url())

#
#
#
#
