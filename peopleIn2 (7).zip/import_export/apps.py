from django.apps import AppConfig


class ImportExportConfig(AppConfig):
    name = 'import_export'
