from django.apps import AppConfig


class SangConfig(AppConfig):
    name = 'sang'
