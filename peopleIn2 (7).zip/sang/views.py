from django.shortcuts import render

# Create your views here.
def sang2(request):
    return render(request, 'sang/sang2.html')